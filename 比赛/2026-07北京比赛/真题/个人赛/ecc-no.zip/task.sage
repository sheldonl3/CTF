from libnum import s2n
from secret import flag
m1=s2n(flag[:len(flag)//2])
m2=s2n(flag[len(flag)//2:])
def lev1(m1):
	p = random_prime(2^256)
	a = random_prime(2^256)
	b = random_prime(2^256)
	E = EllipticCurve(GF(p),[a,b])
	m = E.random_point()
	G = E.random_point()
	k = random_prime(2^256)
	K = k * G
	r = random_prime(2^256)
	c1 = m + r * K
	c2 = r * G
	cipher = m1 * m[0]
	print(f"p = {p}")
	print(f"a = {a}")
	print(f"b = {b}")
	print(f"k = {k}")
	print(E)
	print(f"c1 = {c1}")
	print(f"c2 = {c2}")
	print(f"cipher = {cipher}")

def lev2(m2):
	p=12506217790875063466368723611056175369923
	A=12506217790875063466368723611052784275139
	B=12506217790875063466368723533070038257347
	E = EllipticCurve(GF(p),[A,B])
	P = E.random_point() 
	Q = m2*P
	print(E)
	print(f"P={P}")
	print(f"Q={Q}")

lev1(m1)
lev2(m2)	
