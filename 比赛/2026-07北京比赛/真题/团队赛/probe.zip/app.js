const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// 引入路由模块
const powerRoutes = require('./routes');

// Middleware
app.use(session({
    secret: 'acfd9e1757bf7035',
    resave: false,
    saveUninitialized: true,
}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// 使用路由
app.use('/', powerRoutes);

// 启动服务器
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
