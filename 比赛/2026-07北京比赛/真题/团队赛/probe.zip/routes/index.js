const express = require('express');
const router = express.Router();

const users = Object.create(null); // 存储用户数据，实际应用中应该使用数据库
const power = {};
const powerData = [ // 示例电力数据
    { timestamp: '2024-11-04 12:00', consumption: 120, voltage: 230, current: 0.5 },
    { timestamp: '2024-11-04 13:00', consumption: 110, voltage: 231, current: 0.48 },
    { timestamp: '2024-11-04 14:00', consumption: 130, voltage: 229, current: 0.54 },
];

// 用户注册页面
router.get('/register', (req, res) => {
    res.render('register');
});

// 用户注册处理
router.post('/register', (req, res) => {
    const { username, password } = req.body;
    users[username] = password; // 简单存储，实际应用中需加密
    res.redirect('/login');
});

// 用户登录页面
router.get('/login', (req, res) => {
    res.render('login');
});

// 用户登录处理
router.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (users[username] && users[username] === password) {
        req.session.user = username;
        return res.redirect('/dashboard');
    }
    res.redirect('/login');
});

// 仪表板路由
router.get('/dashboard', (req, res) => {
    const user = req.session.user;
    if (!user) {
        return res.redirect('/login');
    }    
    const userPower = power[user] || {};

    res.render('dashboard', { powerData, userPower });
});

// 设定页面
router.get('/settings', (req, res) => {
    const user = req.session.user;
    if (!user) {
        return res.redirect('/login');
    }
    res.render('settings');
});

// 历史记录页面
router.get('/history', (req, res) => {
    const user = req.session.user;
    if (!user) {
        return res.redirect('/login');
    }
    res.render('history', { powerData });
});

// 登出处理
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

// 首页路由
router.get('/', (req, res) => {
    res.render('login');
});

router.get('/add-monitoring-point', (req, res) => {
    const user = req.session.user;
    if (!user) {
        return res.redirect('/login');
    }
    res.render('add-monitoring-point');
});

router.post('/add-monitoring-point', (req, res) => {
    const user = req.session.user;
    const { pointName, fullAddress, consumption, voltage, current ,currentMonitoringPoint} = req.body;

    if (!user) {
        return res.status(401).send('用户未登录');
    }

    if (!users[user]) {
        users[user] = {};
    }
    if (!power[user]) {
        power[user] = {};
    }

    power[user][pointName] = {
        address: fullAddress,
        consumption: parseFloat(consumption),
        voltage: parseFloat(voltage),
        current: parseFloat(current)
    };
    power[user][currentMonitoringPoint] = pointName;
    res.redirect('/dashboard');
});

module.exports = router;
